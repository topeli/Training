package org.example.repositories;
import org.example.models.Student;
import org.example.models.Training;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TrainingRepository extends JpaRepository<Training, Long> {
}
